'''
File containing the function that generates the html report.
'''

import os
import pandas as pd
import plotly.express as px
import plotly.io as pio
import plotly.graph_objects as go
from sklearn.feature_extraction.text import CountVectorizer, TfidfVectorizer
from nltk.corpus import stopwords
import nltk
import umap
import umap.plot
import re
from src.emotion_colors import colors_report

from wordcloud import WordCloud
import matplotlib.pyplot as plt
import base64
from io import BytesIO


def install_stopwords():
    '''
    Check if user has nltk.corpus.stopwords install and, if not, install it.
    '''
    try:
        stopwords.words('english')
    except LookupError:
        nltk.download("stopwords")
        stopwords.words('english')

def get_colour_dict():
    '''
    Get dictionary used to colour plots
    '''
    
    return colors_report.get_colors()

def get_colour_plot(key):
    '''
    Get colour used in plots for a specific category.
    '''

    return colors_report.get_particular_color(key)


def generate_html_table(df, table_id):
    '''
    Generate a dima,ic datatable from a dataframe
    '''
    # Generate html of the table
    table_html = df.to_html(index=False, classes="display", table_id=table_id, escape=False)
    # Generate javascript code
    topics_table_jav_script = "$(document).ready( function () {"
    topics_table_jav_script += f"$('#{table_id}')"
    topics_table_jav_script += f".DataTable();"
    topics_table_jav_script += "});"

    html_restulting = f'''
    {table_html}
    <script>
    {topics_table_jav_script}
    </script>
'''
    return html_restulting


def generate_report(title, review_dataframe, topic_models, Global_topic_Model,lang="english", path = "", umap_summ_color = ["emotion"],
                    umap_met="cosine", neighbours_umap = 15, min_dist_umap = 0.1, include_table_emotions = False,
                    sentiment_classification = True, group_col = "emotion", show_topics_table = False, multidimension_UMAP = False, marker_size = 1):
    '''
    Generate html report for an exploratory sentiment and topic analysis.
    '''

    # CSS
    css_template = '''
body {
  font-family: sans-serif;
  background-color: #F5F6FA;
  padding: 0;
}

.ContainsAll {
  display: flex;
  flex-direction: row;
  gap: 0;
  padding:0;
}

.ContainerWholeReport{
  padding:2%;
  width: 80%;
}

.navBar{
  padding: 2%;
  background-color: #2A4B7C;
  color: white;
  margin: 0;
  height: 100vh;
  position: fixed;
  z-index: 3;
  top:0;
  left:0;
  list-style-type: none;
}

.navBar li{
  margin-top: 6%;
  list-style-type: disc;
  margin-left: 10%;
}

.navBar h1{
  color: white;
}

.navBar a{
  text-decoration: none;
  color: white;
}

.navBar a:hover{
  color: #FF6B3D;
}

.navBar hr{
  background-color: white;
  border-style: solid;
  border-color: white;
}

.navBarBack{
  width: 18%;
  height: 0;
  background-color: #2A4B7C;
  color: white;
  margin: 0;
}

h1{
  text-align: center;
  width: 100%;
}

h1, h2, h3, h4{
  color: #2A4B7C;
}

a{
  color: #1E90FF;
}

a:hover{
  color: #FF6B3D;
}
footer{
    color: white;
    background-color: #2A4B7C;
    text-align: center;
    padding: 2%;
    margin: -3%;
    margin-top: 2%;
    width: 100%;
}
select, button{
    background-color: white;
    color: black;
    border-color: #2A4B7C;
    border-style: solid;
    border-width: medium;
    font-family: sans-serif;
    margin-bottom: 1%;
}

button:hover{
    background-color: #FF6B3D;
}

.dataTables_wrapper {
  font-family: sans-serif;
  color: black;
}
.dataTables_filter{
  font-family: sans-serif;
  color: black;
}

.Umap_General{
    display: none;
    width: 100%;
}

@media (max-width: 768px) {
    .navBar{
        display: none;
    }
}

'''

    # HTML template script

    # Function to hide and show topic words
    hide_button_function = '''{
    let el = document.getElementById(id_element);
    let b = document.getElementById(id_but);
    if (el.style.display == "none"){
        el.style.display = "block";
        b.innerHTML = "Hide Topics";
    } else{
        el.style.display = "none";
        b.innerHTML = "Show Topics";
    }
    console.log(id_element);
}
'''

    #Function to display the right umap, if there is no umap to show then we do not need it.
    first_umap_col = '0'
    display_umap_function = '{}'
    if len(umap_summ_color) > 0:
        first_umap_col = f'"umap_{umap_summ_color[0]}_id"'
        display_umap_function = '''{
        let prevEl = document.getElementById(previous_display_umap);
        prevEl.style.display = "none";

        let el = document.getElementById(id_element);
        el.style.display = "block";

        previous_display_umap = id_element;
    }
    '''
        
    # Function to show first umap once html is loaded
    onLoad_html = 'window.onload = function(){document.getElementById(previous_display_umap).style.display = "block";}'
    # HTML template

    list_index_emotions = ""

    for k in topic_models.keys():
        list_index_emotions += f'<li><a href="#Semtinment{k}">{k} Texts Analysis</a></li>'

    html_template = f'''
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Include jQuery (required by DataTables) -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

    <!-- Include DataTables CSS (for styling the table) -->
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.11.5/css/jquery.dataTables.css">

    <!-- Include DataTables JS -->
    <script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.js"></script>
    <title>LinguaLoupe: {title}</title>
    <style>
    {css_template}
    </style>
    <script>
        let previous_display_umap = {first_umap_col};
        {onLoad_html}
        function HideButton(id_element, id_but){hide_button_function}
        function DisplayRightUmap(id_element){display_umap_function}
    </script>
</head>
<body>
    <div class="ContainsAll">
    <ul class="navBar">
      <h1>LinguaLoupe</h1>
      <hr>
      <label style="font-weight: bold;">Go to:</label>
      <li><a href="#Summary">Summary</a></li>
      {list_index_emotions}
    </ul>
    <div class="navBarBack">
    </div>
    <div class="ContainerWholeReport">
    <main>
        <h1>{title}</h1>
'''

    # Defining which are the min and max topics for later plots.
    low_topic = Global_topic_Model[1]["Topic"].min()
    max_topic = Global_topic_Model[1]["Topic"].max()

    def generate_overview():
        # Create a Word Cloud of all texts associated with that emotion, regex removes urls
        all_texts_single_string = " ".join(re.sub(r"http\S+|www\.\S+", "", review) for review in review_dataframe["text"])
        stopwords_word_cloud = stopwords.words(lang)
        wordcloud = WordCloud(stopwords=stopwords_word_cloud, background_color="white").generate(all_texts_single_string)
        
        fig, ax = plt.subplots(figsize = (15, 8))
        ax.imshow(wordcloud, interpolation='bilinear')
        ax.axis("off")

        tmpfile = BytesIO()
        fig.savefig(tmpfile, format='png')
        html_str_wordcloud = base64.b64encode(tmpfile.getvalue()).decode('utf-8')

        # UMAP
        if Global_topic_Model[1].shape[0] < 2:
            return f"<div><p>Could not find global topics.</p></div>"
        
        model = Global_topic_Model[0]

        if Global_topic_Model[1].shape[0] < 2:
            umap_div = '<p style="color: red;">Not enougth topics to generate UMAP.</p>'
            hierarchical_div = '<p style="color: red;">Not enougth topics to perform hierarchical clustering.</p>'
        else:
            try:
                umap_em = model.visualize_topics(use_ctfidf = False)
                umap_div = pio.to_html(umap_em, full_html=False, include_plotlyjs="cdn")
            except Exception as e:
                umap_div = f'<p style="color: red;">Umap could not be generated: {e}.</p>'
            hierarchical_em = model.visualize_hierarchy()
            hierarchical_div = pio.to_html(hierarchical_em, full_html=False, include_plotlyjs="cdn")
        # Heatmap
        heatmap_em = model.visualize_heatmap(use_ctfidf = False)
        heatmap_div = pio.to_html(heatmap_em, full_html=False, include_plotlyjs="cdn")
        # Barchart of words
        barplot_em = model.visualize_barchart(top_n_topics=len(model.get_topics()), n_words = 10)
        barplot_em.update_layout(title={
            'text': '<b>Topic Word Scores</b>',
            'font': {'size': 24, 'family': 'Arial', 'color': 'black'},  # Size and font
            'x': 0.5,  # Centered title
        })
        #barplot_em.update_traces(marker_color=emotion_colours[em])
        barplot_div = pio.to_html(barplot_em, full_html=False, include_plotlyjs="cdn")

        # topic frequencies
        topics_freqs_dataframe = Global_topic_Model[1]
        topics_freqs_dataframe["Topic"] = topics_freqs_dataframe["Topic"].astype(str)
        topic_counts_barplot = px.bar(topics_freqs_dataframe, x="Topic", y="Count", title="Topic Counts")
        topic_counts_barplot.update_layout(title={
            'text': '<b>Topic Counts</b>',
            'font': {'size': 24, 'family': 'Arial', 'color': 'black'},  # Size and font
            'x': 0.5,  # Centered title
        }, showlegend=False)
        topic_counts_barplot.update_xaxes(type='category')
        #topic_counts_barplot.update_traces(marker_color=emotion_colours[em])
        barplot_topics_freq_div = pio.to_html(topic_counts_barplot, full_html=False, include_plotlyjs="cdn")  

        res = f'''
        <h3 id="Wordcloud">Word cloud</h3>
        <p>Most frequent words across all texts. The bigger the word the most frequent it is.</p>
        <img src='data:image/png;base64,{html_str_wordcloud}'>
        <h4 id="TopicFreqs">Global Topic Counts</h4>
        <p>Barplot displaying how many times a topic appears.</p>
        {barplot_topics_freq_div}
        <h4 id="Intertopic">Intertopic distance map</h4>
        <p>A Umap visualization generated in a way very similar to <a href="https://github.com/cpsievert/LDAvis">LDAvis</a>.</p>
        <p>The clusters are based on the embeddings from the embedding model, or in other words, they are determined by the semantic meaning of the words in each topic rather than what is explicitly written in them.</p>
        {umap_div}
        <h4 id="Hclust">Hierarchcial clustering</h4>
        <p>A graph displaying the potential hierarchy of topics.</p>
        <p>It uses c-TF-IDF representations for computing the similarities between topics, or in other words, the similarity between topics is determined by the words explicitly written in them.</p>
        {hierarchical_div}
        <h4 id="WordScore">Topic Word Score</h4>
        <p>c-TF-IDF scores of each topic, you can visualize the most meaningfull words for each of the topics.</p>
        <button id="but_id_topics_show" onclick="HideButton(this.value, this.id)" value="topics_barplots_tf">Show Topics</button>
        <div id="topics_barplots_tf" style="display: none;">
            {barplot_div}
        </div>
        <h4 id="Sim">Similarity Matrix</h4>
        <p>A heatmap showing how similar the topics are between them.</p>
        {heatmap_div}
        '''

        if show_topics_table == True:
            # Topic most representative documents and AI summary
            topic_documents_df = Global_topic_Model[1]
            topic_documents_df.drop(['Count', 'Main Words', 'c-TF-IDF score', 'Most representative texts'], axis = 1, inplace = True)
            topic_documents_df.rename(columns = {'Most representative texts HTML': 'Most representative texts'}, inplace = True)
            table_topic_html = generate_html_table(topic_documents_df, 'Table_Topics_Global')
            res += f'''
        <h4 id="SummaryGlobalTopicsTable">Most representative texts for each topic</h4>
        <p>A table displaying the most representative texts for each topic.</p>
        {table_topic_html}
'''

        return res

    def generate_html_for_emotion(em):
        # Dataframe emotions
        em_df = review_dataframe[review_dataframe[group_col] == em]

        # Create a Word Cloud of all texts associated with that emotion
        all_texts_single_string = " ".join(re.sub(r"http\S+|www\.\S+", "", review) for review in em_df["text"])
        stopwords_word_cloud = stopwords.words(lang)
        wordcloud = WordCloud(stopwords=stopwords_word_cloud, background_color="white").generate(all_texts_single_string)
        
        fig, ax = plt.subplots(figsize = (15, 8))
        ax.imshow(wordcloud, interpolation='bilinear')
        ax.axis("off")

        tmpfile = BytesIO()
        fig.savefig(tmpfile, format='png')
        html_str_wordcloud = base64.b64encode(tmpfile.getvalue()).decode('utf-8')

        #html_str_wordcloud = mpld3.fig_to_html(fig)

        # Trigrams
        cv = CountVectorizer(ngram_range=(3, 3), max_features=5000, min_df=5)
        bigrams = cv.fit_transform(em_df["text"])
        count_values = bigrams.toarray().sum(axis=0)
        ngram_freq = pd.DataFrame(sorted([(count_values[i], k) for k, i in cv.vocabulary_.items()], reverse = True))
        ngram_freq.columns = ["Count", "Trigram"]
        barplot_trigrams = px.bar(ngram_freq.head(10),x="Count", y="Trigram",
                                  category_orders={"Trigram": ngram_freq["Trigram"].to_list()},
                                  title="Top 10 Trigrams")
        barplot_trigrams.update_layout(title={
            'text': '<b>Top 10 Trigrams</b>',
            'font': {'size': 24, 'family': 'Arial', 'color': 'black'},  # Size and font
            'x': 0.5,  # Centered title
        }, showlegend=False)
        barplot_trigrams.update_traces(marker_color=get_colour_plot(em))
        bigram_plot_div = pio.to_html(barplot_trigrams,
                                      full_html=False, include_plotlyjs="cdn")


        if topic_models[em][1].shape[0] < 2:
            return f"<div><p>Could not find topics for {em}</p></div>"
        
        model = topic_models[em][0]
        # UMAP
        if topic_models[em][1].shape[0] < 2:
            umap_div = '<p style="color: red;">Not enougth topics to generate UMAP.</p>'
            hierarchical_div = '<p style="color: red;">Not enougth topics to perform hierarchical clustering.</p>'
        else:
            try:
                umap_em = model.visualize_topics(use_ctfidf = False)
                umap_div = pio.to_html(umap_em, full_html=False, include_plotlyjs="cdn")
            except Exception as e:
                umap_div = f'<p style="color: red;">Umap could not be generated: {e}.</p>'
            hierarchical_em = model.visualize_hierarchy()
            hierarchical_div = pio.to_html(hierarchical_em, full_html=False, include_plotlyjs="cdn")
        # Heatmap
        heatmap_em = model.visualize_heatmap(use_ctfidf = False)
        heatmap_div = pio.to_html(heatmap_em, full_html=False, include_plotlyjs="cdn")
        # Barchart of words
        barplot_em = model.visualize_barchart(top_n_topics=len(model.get_topics()), n_words = 10)
        barplot_em.update_layout(title={
            'text': '<b>Topic Word Scores</b>',
            'font': {'size': 24, 'family': 'Arial', 'color': 'black'},  # Size and font
            'x': 0.5,  # Centered title
        })
        barplot_em.update_traces(marker_color=get_colour_plot(em))
        barplot_div = pio.to_html(barplot_em, full_html=False, include_plotlyjs="cdn")
        # Global topic frequencies
        
        # global_probability_topic
        labels_topic = list(map(str, range(low_topic, max_topic + 1, 1)))

        global_topics_freqs_dataframe = (
            em_df[em_df["global_topic"] >= 0]["global_topic"].value_counts().reindex(
                range(low_topic, max_topic + 1, 1),
                fill_value = 0
                ).reset_index()
        )

        global_topics_freqs_dataframe.columns = ["global_topic", "count"]

        global_topics_freqs_dataframe["Global Topic"] = global_topics_freqs_dataframe["global_topic"].astype(str)

        global_topic_counts_barplot = px.bar(
            global_topics_freqs_dataframe,
            x="Global Topic",
            y="count",
            title="Global Topic Counts",
            category_orders={"Global Topic": labels_topic}
        )

        #global_topics_freqs_dataframe["Topic"] = topics_freqs_dataframe["Topic"].astype(str)
        #global_topic_counts_barplot = px.bar(global_topics_freqs_dataframe, x="global_topics_freqs_dataframe", y="count", title="Topic Counts")
        global_topic_counts_barplot.update_layout(title={
                'text': '<b>Global Topic Counts</b>',
                'font': {'size': 24, 'family': 'Arial', 'color': 'black'},  # Size and font
                'x': 0.5,  # Centered title
            }, showlegend=False
        )

        global_topic_counts_barplot.update_traces(marker_color=get_colour_plot(em))
        global_barplot_topics_freq_div = pio.to_html(global_topic_counts_barplot, full_html=False, include_plotlyjs="cdn")
        
        
        # topic frequencies
        topics_freqs_dataframe = topic_models[em][1]
        topics_freqs_dataframe["Topic"] = topics_freqs_dataframe["Topic"].astype(str)
        topic_counts_barplot = px.bar(topics_freqs_dataframe, x="Topic", y="Count", title="Topic Counts")
        topic_counts_barplot.update_layout(title={
            'text': '<b>Topic Counts</b>',
            'font': {'size': 24, 'family': 'Arial', 'color': 'black'},  # Size and font
            'x': 0.5,  # Centered title
        }, showlegend=False)
        topic_counts_barplot.update_traces(marker_color=get_colour_plot(em))
        topic_counts_barplot.update_xaxes(type='category')
        barplot_topics_freq_div = pio.to_html(topic_counts_barplot, full_html=False, include_plotlyjs="cdn")
        # Showing reviews with each emotion
        
        # Making an interacteable table to show the diferent text included in the review
        table_emotion = em_df.to_html(index=False, classes="display", table_id=f"table_{em}")
        # Creating dropdown to filter table by topic
        dropdown_topic_menu = f'<label for="topics_filter_{em}">Topics:</label> <select name="topics_filter_{em}" id="topics_filter_{em}" onchange="Filter_Topic_{em}()"><option value="All">All</option>'
        for t in topics_freqs_dataframe["Topic"]:
            dropdown_topic_menu += f'<option value="{t}">{t}</option>'
        dropdown_topic_menu += "</select>"
        # javascript for the emotion
        style_sel_input = '''
{
              language: {
                    lengthMenu:
                        'Display <select style="background-color: white; color: black; border-color: #2A4B7C; border-style: solid; border-width: medium; font-family: sans-serif; margin-bottom: 1%;">' +
                        '<option value="5">5</option>' +
                        '<option value="10">10</option>' +
                        '<option value="15">15</option>' +
                        '<option value="20">20</option>' +
                        '<option value="25">25</option>' +
                        '<option value="30">30</option>' +
                        '<option value="35">35</option>' +
                        '<option value="40">40</option>' +
                        '<option value="45">45</option>' +
                        '<option value="50">50</option>' +
                        '</select> records'
                },
            pageLength : 5
            }
'''
        jav_script = "$(document).ready( function () {"
        jav_script += f"table{em} = $('#table_{em}')"
        jav_script += f".DataTable({style_sel_input});"
        jav_script += "});"
        # Function to filter table entries by topic
        fun_filter = "{"
        fun_filter += f'let f = document.getElementById("topics_filter_{em}").value;'
        fun_filter += "if (f == 'All'){"
        fun_filter += f"table{em}"
        fun_filter += '.column(-2).search("", true, false).draw();'
        fun_filter += '}else{'
        fun_filter += f"table{em}"
        fun_filter += '.column(-2).search(`^${f}` + "$", true, false).draw();}}'
        # resulting div
        res = f'''
        <div>
            <h3 id="Semtinment{em}">{em}</h3>
            <h4>Word Cloud</h4>
            <p>Word Cloud of all text associated with this category.</p>
            <img src='data:image/png;base64,{html_str_wordcloud}'>
            <h4>Top 10 most frequent Trigrams</h4>
            {bigram_plot_div}
            <h4 id="TopicFreqsGlobal{em}">Global Topic Counts {em}</h4>
            <p>Barplot displaying how many times a global topic appears for this category.</p>
            {global_barplot_topics_freq_div}
            <h4 id="TopicFreqs{em}">Topic Counts {em}</h4>
            <p>Barplot displaying how many times a topic appears in a topic classification of only {em} texts.</p>
            {barplot_topics_freq_div}
            <h4 id="Intertopic{em}">Intertopic distance map</h4>
            <p>A Umap visualization generated in a way very similar to <a href="https://github.com/cpsievert/LDAvis">LDAvis</a>.</p>
            <p>The clusters are based on the embeddings from the embedding model, or in other words, they are determined by the semantic meaning of the words in each topic rather than what is explicitly written in them.</p>
            {umap_div}
            <h4 id="Hclust{em}">Hierarchcial clustering</h4>
            <p>A graph displaying the potential hierarchy of topics.</p>
            <p>It uses c-TF-IDF representations for computing the distance between topics, or in other words, the similarity between topics is determined by the words explicitly written in them.</p>
            {hierarchical_div}
            <h4 id="WordScore{em}">Topic Word Score</h4>
            <p>c-TF-IDF scores of each topic, you can visualize the most meaningfull words for each of the topics.</p>
            <button id="{em}_positive_but_id_topics_show" onclick="HideButton(this.value, this.id)" value="{em}_topics_barplots_tf">Show Topics</button>
            <div id="{em}_topics_barplots_tf" style="display: none;">
                {barplot_div}
            </div>
            <h4 id="Sim{em}">Similarity Matrix</h4>
            <p>A heatmap showing how similar the topics are between them.</p>
            {heatmap_div}
        '''

        if include_table_emotions == True:
            res += f'''
            <h4 id="table{em}">{em} texts</h4>
            <p>The texts that were considered to belong to: {em}</p>
            {dropdown_topic_menu}
            {table_emotion}
            <script>
            let table{em};
            {jav_script}
            function Filter_Topic_{em}(){fun_filter}
            </script>
            '''

        if show_topics_table == True:
            # Topic most representative documents and AI summary
            topics_freqs_dataframe.drop(['Count', 'Main Words', 'c-TF-IDF score', 'Most representative texts'], axis = 1, inplace = True)
            topics_freqs_dataframe.rename(columns = {'Most representative texts HTML': 'Most representative texts'}, inplace = True)
            emotion_table_topic_html = generate_html_table(topics_freqs_dataframe, f'Table_{em}_Topics_Rep')
            res += f'''
            <h4 id="SummaryTopicsTable{em}">Most representative texts for each topic</h4>
            <p>A table displaying the most representative texts for each topic.</p>
            {emotion_table_topic_html}
        '''

        res += "</div>"

        return res

    # If sentiment classification has been performed, create the appropiate plots divided correctly.
    df_emotion_length = pd.DataFrame()
    df_emotion_length["text_word_length"] = review_dataframe["text"].apply(lambda x: len(x.split()))
    
    if sentiment_classification:
        # Histogram
        histogram_emotions = px.histogram(review_dataframe, x = group_col, color=group_col, color_discrete_map=get_colour_dict(),
                                          title=group_col)
        
        histogram_emotions.update_layout(showlegend=False, title={
            'text': f'<b>{group_col}</b>',
            'font': {'size': 24, 'family': 'Arial', 'color': 'black'},  # Size and font
            'x': 0.5,  # Centered title
        })
        div_histogram = pio.to_html(histogram_emotions, full_html=False, include_plotlyjs="cdn")

        # Boxplot review length
    
        df_emotion_length[group_col] = review_dataframe[group_col]
    
        boxplot_review_length = px.box(df_emotion_length, x=group_col, y="text_word_length", color=group_col, color_discrete_map=get_colour_dict(),
                                   labels={"text_word_length": "Amount of words"}, title="Word Count")
    else:
        boxplot_review_length = px.box(df_emotion_length, y="text_word_length",
                                       labels={"text_word_length": "Amount of words"}, title="Word Count")
    
    boxplot_review_length.update_layout(showlegend=False, title={
        'text': '<b>Word Count</b>',
        'font': {'size': 24, 'family': 'Arial', 'color': 'black'},  # Size and font
        'x': 0.5,  # Centered title
    })

    boxplot_review_length.update_traces(boxmean = True)

    boxplot_review_length_div = pio.to_html(boxplot_review_length, full_html=False, include_plotlyjs="cdn")

    # Dimensionality reduction visualisation UMAP

    tfidf_vectorizer = TfidfVectorizer(min_df=5, stop_words=stopwords.words(lang))
    tfidf_word_doc_matrix = tfidf_vectorizer.fit_transform(review_dataframe["text"])

    components_overview_umap = 2
    if multidimension_UMAP == True:
        components_overview_umap = 3
    
    tfidf_umap = umap.UMAP(n_components=components_overview_umap,metric=umap_met, min_dist=min_dist_umap, n_neighbors=neighbours_umap)
    tfidf_embedding = tfidf_umap.fit_transform(tfidf_word_doc_matrix)
    
    # Colour umap by different columns

    # select to decide which umap to show

    select_umaps_dropdown = 'Color by: <select onchange="DisplayRightUmap(this.value)">'

    umaps_Divs = ""

    for variable in umap_summ_color:
        # Create scatter plot from umap coloring by variable
        if multidimension_UMAP == True:
            umap_fig_em = px.scatter_3d(
                x = tfidf_embedding[:,0],
                y = tfidf_embedding[:,1],
                z = tfidf_embedding[:,2],
                color=review_dataframe[variable],
                color_discrete_map=get_colour_dict(),
                title=variable,
                labels = {
                    'x': 'UMAP 1',
                    'y': 'UMAP 2',
                    'z': 'UMAP 3'
                },
                hover_data = {
                    'index':  review_dataframe.index.astype(str)
                }
            )
        else:
            umap_fig_em = px.scatter(
                x = tfidf_embedding[:,0],
                y = tfidf_embedding[:,1],
                color=review_dataframe[variable],
                color_discrete_map=get_colour_dict(),
                title=variable,
                labels = {
                    'x': 'UMAP 1',
                    'y': 'UMAP 2'
                },
                hover_data = {
                    'index':  review_dataframe.index.astype(str)
                }
            )
    
        umap_fig_em.update_layout(title = {
            'text': '<b>UMAP</b>',
            'font': {'size': 24, 'family': 'Arial', 'color': 'black'},  # Size and font
            'x': 0.5,  # Centered title
        })

        umap_fig_em.update_traces(marker_size=marker_size)
        
        # Create div that will contain the umap
        umap_fig_em_div = pio.to_html(umap_fig_em, full_html=False, include_plotlyjs="cdn")

        id_umap = f"umap_{variable}_id"
        select_umaps_dropdown += f'<option value="{id_umap}">{variable}</option>'


        div_umap = f'''
        <div id="{id_umap}" class="Umap_General">
        {umap_fig_em_div}
        </div>
'''
        
        umaps_Divs += div_umap
        
    # Close select
    select_umaps_dropdown += "</select>"

    # Segment of html that shows general information without the umap.

    html_summary = f'''
    <div>
        <h2 id="Summary">Summary</h2>
'''
    separator_overview_sentiments = ""

    if sentiment_classification:
        html_summary += f'''
        <h3 id="HistogramSentiment">Amount of texts per category</h3>
        <p>Histogram displaying the amount of text that belong to each category.</p>
        {div_histogram}
'''

        if group_col == "emotion":
            separator_overview_sentiments += "<h2>Sentiment Analysis</h2>"
        else:
            separator_overview_sentiments += f"<h2>{group_col}</h2>"


    html_summary += f'''

        <h3 id="WordCount">Amount of words per category</h3>
        <p>Boxplot showing the amount of words each text in a category have.</p>
        {boxplot_review_length_div}
        <h3 id="UmapEmotions">Umap reviews</h3>
        <p>A UMAP to see how similar the text of each category are.</p>
        {select_umaps_dropdown}
        {umaps_Divs}
        <br><br><br>
        {generate_overview()}
'''

    # Adding umaps to general section of html and closing the div
    html_summary += "</div>"

    emotion_sections = []

    # Topics plots
    for k in topic_models.keys():
        div_emotion = generate_html_for_emotion(k)
        emotion_sections.append(div_emotion)

#    html_end = '''
#</main>
#    </div>
#    </div>
#    <footer>
#        Report created using LinguaLoupe.
#    </footer>
#</body>
#</html>
#'''
    
    html_final = "\n".join([html_template, html_summary, separator_overview_sentiments,"\n".join(emotion_sections)])
    
    with open(os.path.join(path, "report.html"), "w+") as file:
        file.write(html_final)

    return html_final